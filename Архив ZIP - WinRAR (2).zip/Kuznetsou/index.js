const express = require('express')
const app = express()
app.set('view engine', 'ejs')
app.set ('views','./templates')
app.use (express.static('public'))
app.get('/', function (req, res) {
  res.render('index', {name: "Kuznetsov", id: 1337})
})
app.get('/search', function (req, res) {
    res.render('search')
  })
let port=3000
app.listen(port,  () => {console.log (`Cервер запущен ${port}`)})